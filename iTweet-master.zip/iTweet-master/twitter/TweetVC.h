//
//  TweetVC.h
//  twitter
//
//  Created by Vinu Charanya on 10/23/13.
//  Copyright (c) 2013 codepath. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Tweet.h"

@interface TweetVC : UIViewController

- (id)initWithTweet:(Tweet *)tweet;

@end
