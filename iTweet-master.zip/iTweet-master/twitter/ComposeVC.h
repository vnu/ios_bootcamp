//
//  ComposeVC.h
//  twitter
//
//  Created by Vinu Charanya on 10/23/13.
//  Copyright (c) 2013 codepath. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComposeVC : UIViewController
@property (weak, nonatomic) NSString *rTweetID;
@end
