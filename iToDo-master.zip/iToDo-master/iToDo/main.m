//
//  main.m
//  iToDo
//
//  Created by Vinu Charanya on 10/16/13.
//  Copyright (c) 2013 vnu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "VnuAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([VnuAppDelegate class]));
    }
}
