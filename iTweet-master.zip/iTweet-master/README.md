### Simple iOS Twitter client

This is a simple iOS Twitter client that is meant as a demonstration for architecting a RESTful API client.
