//
//  VnuAppDelegate.h
//  iToDo
//
//  Created by Vinu Charanya on 10/16/13.
//  Copyright (c) 2013 vnu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VnuAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
